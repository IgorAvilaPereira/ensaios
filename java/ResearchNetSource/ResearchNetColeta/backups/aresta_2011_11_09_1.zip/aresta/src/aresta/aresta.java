package aresta;

import java.sql.*;
import java.util.*;

public class aresta {
    List<publicacao> listaPublicacoes;
    List<publicacao> listaImprime;
    
    public aresta(Integer id_membro1, Integer id_membro2) throws ClassNotFoundException {
        try{
            Class.forName("org.postgresql.Driver");

            String url = "jdbc:postgresql://localhost/lattes?user=postgres&password=postgres";
            Connection conn = DriverManager.getConnection(url);   
            
            //Integer id_membro1=4;
            //Integer id_membro2=16;

            List<publicacao> listaPublicacoes = new LinkedList<publicacao>();
            List<publicacao> listaImprime = new LinkedList<publicacao>();
            String query="select id_publicacao,titulo,autores,ano,id_membro,cluster,tipo from publicacoes_com_replica where id_membro="+id_membro1.toString()+" or id_membro="+id_membro2.toString();

            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            
            while (rs.next()) {
                publicacao pub = new publicacao();
                pub.id_publicacao=rs.getInt(1);
                pub.titulo=rs.getString(2);
                pub.autores=rs.getString(3);
                pub.ano=rs.getString(4);
                pub.id_membro=rs.getInt(5);
                pub.cluster=rs.getInt(6);
                pub.tipo=rs.getString(7);               
                
                listaPublicacoes.add(pub);
            }
            for(int i=0;i<listaPublicacoes.size();i++)
            {
                if(listaPublicacoes.get(i).tipo.equals("AP")){
                    query="select revista from revista where id_publicacao="+listaPublicacoes.get(i).id_publicacao.toString();
                }
                else if(listaPublicacoes.get(i).tipo.equals("CL")){
                    query="select livro from capitulo where id_publicacao="+listaPublicacoes.get(i).id_publicacao.toString();
                }
                else if(listaPublicacoes.get(i).tipo.equals("TC")){
                    query="select evento from conferencia where id_publicacao="+listaPublicacoes.get(i).id_publicacao.toString();
                }
                else if(listaPublicacoes.get(i).tipo.equals("AA")){
                    query="select revista from revista_aceito where id_publicacao="+listaPublicacoes.get(i).id_publicacao.toString();
                }
                rs= st.executeQuery(query);
                rs.next();
                listaPublicacoes.get(i).localPublicado=rs.getString(1);
            }
            
            
            rs.close();
            st.close();
            
            for(int i=0;i<listaPublicacoes.size()-1;i++)
            {
                if(listaPublicacoes.get(i).cluster==listaPublicacoes.get(i+1).cluster)
                {
                    listaImprime.add(listaPublicacoes.get(i));
                    listaPublicacoes.get(i).replica=listaPublicacoes.get(i+1);
                }   
            }   
            
        new guiListaPublicacoes();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        catch(java.lang.ArrayIndexOutOfBoundsException e)
        {
            System.out.println("Parâmetros inválidos");
        }
    }
}
