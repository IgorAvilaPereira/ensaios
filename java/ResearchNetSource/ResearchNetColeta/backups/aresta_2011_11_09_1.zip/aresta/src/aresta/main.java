package aresta;

import java.util.List;

public class main {
    static aresta Aresta1;
    public static void main(String args[]) throws ClassNotFoundException
    {
       Integer id_membro1=Integer.parseInt(args[0]);
       Integer id_membro2=Integer.parseInt(args[1]);
       Aresta1 = new aresta(id_membro1,id_membro2);
    }
    
        
    public static List<publicacao> getListaPublicacoes()
    {
        return Aresta1.listaPublicacoes;
    }
    
    public static List<publicacao> getListaImprime()
    {
        return Aresta1.listaImprime;
    }

}
