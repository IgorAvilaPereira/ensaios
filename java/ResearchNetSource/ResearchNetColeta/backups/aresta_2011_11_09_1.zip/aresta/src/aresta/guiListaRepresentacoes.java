package aresta;

import java.util.List;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class guiListaRepresentacoes {
    public guiListaRepresentacoes(int clicked){
        JFrame janela= new JFrame("");
        JLabel repres1;
        JLabel repres2;
        
        
        repres1 = new JLabel(main.getListaImprime().get(clicked).toString());
        repres2 = new JLabel(main.getListaImprime().get(clicked).replica.toString());
        
        janela.add(repres1);
        janela.add(repres2);

    }
}
