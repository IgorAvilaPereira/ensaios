package aresta;

import java.sql.*;
import java.util.*;

class Publicacao{
    String titulo;
    int id,cluster;    
}

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException {
        try{
            Class.forName("org.postgresql.Driver");

            String url = "jdbc:postgresql://localhost/lattes?user=postgres&password=postgres";
            Connection conn = DriverManager.getConnection(url);

            //Integer id_membro1=Integer.parseInt(args[0]);
            //Integer id_membro2=Integer.parseInt(args[1]);

            Integer id_membro1=10;
            Integer id_membro2=19;

            List<Publicacao> listaPublicacoes = new LinkedList<Publicacao>();
            String query="select titulo,id_membro,cluster from publicacoes_com_replica where id_membro="+id_membro1.toString()+" or id_membro="+id_membro2.toString();

            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                Publicacao pub = new Publicacao();
                pub.titulo=rs.getString(1);
                pub.id=rs.getInt(2);
                pub.cluster=rs.getInt(3);
                listaPublicacoes.add(pub);
            }
            rs.close();
            st.close();

            for(int i=0;i<listaPublicacoes.size()-1;i++)
            {
                if(listaPublicacoes.get(i).cluster==listaPublicacoes.get(i+1).cluster)
                {
                    System.out.println(listaPublicacoes.get(i).titulo);
                }
            }
            
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }

}
