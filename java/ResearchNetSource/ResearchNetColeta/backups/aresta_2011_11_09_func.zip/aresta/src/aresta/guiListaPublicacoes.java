package aresta;

import java.awt.BorderLayout;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;


public class guiListaPublicacoes extends JFrame {
    public guiListaPublicacoes(){
        //Object[] toArray = listaImprime.toArray();
        
        JFrame janela= new JFrame("Lista de Publicações em Comum");

        janela.setLayout(new BorderLayout());
        
        JList lista= new JList();
        DefaultListModel modeloLista= new DefaultListModel();
        
        for(int i=0;i<aresta.listaImprime.size();i++)
        {
            modeloLista.addElement(aresta.listaImprime.get(i));
        }
        lista.setModel(modeloLista); 
        
              
        lista.addMouseListener(new mouseLista(lista));
        
        
        JScrollPane scroll = new JScrollPane(lista);  
        lista.setBorder(javax.swing.BorderFactory.createEtchedBorder());  
                        
        janela.add(scroll);

        janela.setSize(800,400);
        janela.setVisible(true);
        janela.setLocationRelativeTo(null);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.setVisible(true);
    }
    
}