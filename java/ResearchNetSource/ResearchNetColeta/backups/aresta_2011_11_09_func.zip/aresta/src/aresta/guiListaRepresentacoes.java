package aresta;

import java.awt.BorderLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

public class guiListaRepresentacoes {
    public guiListaRepresentacoes(int clicked){
        JFrame janela= new JFrame("Representações");
//        JLabel repres1,repres2;
//        
//        JPanel panel = new JPanel();
//        panel.setLayout(new BorderLayout());
//        
//        repres1 = new JLabel(aresta.listaImprime.get(clicked).toString());        
//        repres2 = new JLabel(aresta.listaImprime.get(clicked).replica.toString());
//                
//        janela.getContentPane().add(repres1, BorderLayout.PAGE_START);
//        janela.getContentPane().add(repres2, BorderLayout.CENTER);
//        
//        
        JList lista= new JList();
        DefaultListModel modeloLista= new DefaultListModel();
        
        String repres1 = "<html>Currículo de origem: "+aresta.listaImprime.get(clicked).nome_membro+"<br>"+aresta.listaImprime.get(clicked).toString().substring(6);
        String repres2 = "<html>Currículo de origem: "+aresta.listaImprime.get(clicked).replica.nome_membro+"<br>"+aresta.listaImprime.get(clicked).replica.toString().substring(6);
        
        modeloLista.addElement(repres1);
        modeloLista.addElement(repres2);
           
        lista.setModel(modeloLista); 
        
        JScrollPane scroll = new JScrollPane(lista);  
        lista.setBorder(javax.swing.BorderFactory.createEtchedBorder());  
        
        
        janela.add(scroll,BorderLayout.NORTH);
        
        JOptionPane opcoes = new JOptionPane();
        janela.add(opcoes,BorderLayout.SOUTH);
        
        
        janela.setSize(600,300);
        janela.setVisible(true);
        janela.setLocationRelativeTo(null);
        janela.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janela.setVisible(true);

    }
}
