package aresta;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JList;
import javax.swing.ListModel;

public class mouseLista extends MouseAdapter{
   protected JList list;
   public mouseLista(JList l){
   list = l;
   }
    
    @Override
  public void mouseClicked(MouseEvent e){
   if(e.getClickCount() == 2){
     int index = list.locationToIndex(e.getPoint());
     ListModel dlm = list.getModel();
     Object item = dlm.getElementAt(index);
     list.ensureIndexIsVisible(index);
     System.out.println("Double clicked on " + index);
     new guiListaRepresentacoes(index);
     
     }
   }
    
}
