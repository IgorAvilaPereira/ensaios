package aresta;

public class publicacao{
    String titulo, autores, ano, localPublicado, tipo, nome_membro;
    int cluster, id_membro;
    Integer id_publicacao;
    publicacao replica;
    
    @Override
    public String toString()
    {
        StringBuilder str = new StringBuilder();
        str.append("<html>Autores: ");
        str.append(autores);
        str.append("<br>Título: ");
        str.append(titulo);
        if(tipo.equals("AA"))
        {
            str.append("<br>Revista: ");
        }
        else if(tipo.equals("AP"))
        {
            str.append("<br>Revista: ");
        }
        else if(tipo.equals("CL"))
        {
            str.append("<br>Livro: ");
        }
        else if(tipo.equals("TC"))
        {
            str.append("<br>Evento: ");
        }
        
        if(!tipo.equals("LP"))
        {
            str.append(localPublicado);            
        }
        str.append("<br>Ano: ");
        str.append(ano);
        str.append("<br> - </html>");
        return str.toString();
    }
}
