package aresta;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class comunicacao {
    public static void comunicacao(){
        try{
            Class.forName("org.postgresql.Driver");

            String url = "jdbc:postgresql://localhost/lattes?user=postgres&password=postgres";
            Connection conn = DriverManager.getConnection(url);
            
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        catch (ClassNotFoundException ex) 
        {
                ex.printStackTrace();
        }
    }
        
}
