package aresta;

public class publicacao{
    String titulo, autores, ano, localPublicado, tipo, nome_membro;
    int cluster, id_membro;
    Integer id_publicacao;
    publicacao replica;
    
    @Override
    public String toString()
    {
        StringBuilder str = new StringBuilder();
        str.append("<html><i>Autores: </i>");
        str.append(autores);
        str.append("<br><i>Título: </i> ");
        str.append(titulo);
        if(tipo.equals("AA"))
        {
            str.append("<br><i>Revista: </i>");
        }
        else if(tipo.equals("AP"))
        {
            str.append("<br><i>Revista: </i>");
        }
        else if(tipo.equals("CL"))
        {
            str.append("<br><i>Livro:</i> ");
        }
        else if(tipo.equals("TC"))
        {
            str.append("<br><i>Evento: </i>");
        }
        
        if(!tipo.equals("LP"))
        {
            str.append(localPublicado);            
        }
        str.append("<br><i>Ano: </i>");
        str.append(ano);
        str.append("<br> - </html>");
        return str.toString();
    }
}
