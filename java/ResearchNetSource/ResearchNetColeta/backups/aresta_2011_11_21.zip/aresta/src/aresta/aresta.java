package aresta;

import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class aresta {
    public static List<publicacao> listaPublicacoes;
    public static List<publicacao> listaImprime;
    public static Integer id_membro1;
    public static Integer id_membro2;
    public static String nome_membro1;
    public static String nome_membro2;
    
    public static void main(String args[]){
        try{
            try {
                Class.forName("org.postgresql.Driver");
            } catch (ClassNotFoundException ex) {
                System.out.println(ex);
            }

            String url = "jdbc:postgresql://localhost/lattes?user=postgres&password=postgres";
            Connection conn = DriverManager.getConnection(url);   
            
            try{
                id_membro1=Integer.parseInt(args[0]);
                id_membro2=Integer.parseInt(args[1]);
            }
            catch(java.lang.ArrayIndexOutOfBoundsException e)
            {
                id_membro1=10;
                id_membro2=19;
            }
            
            
            //Integer id_membro1=4;
            //Integer id_membro2=16;

            listaPublicacoes = new LinkedList<publicacao>();
            listaImprime = new LinkedList<publicacao>();
            String query="select id_publicacao,titulo,autores,ano,id_membro,cluster,tipo from publicacoes_com_replica where id_membro="+id_membro1.toString()+" or id_membro="+id_membro2.toString();

            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            
            while (rs.next()) {
                publicacao pub = new publicacao();
                pub.id_publicacao=rs.getInt(1);
                pub.titulo=rs.getString(2);
                pub.autores=rs.getString(3);
                pub.ano=rs.getString(4);
                pub.id_membro=rs.getInt(5);
                pub.cluster=rs.getInt(6);
                pub.tipo=rs.getString(7);               
                
                listaPublicacoes.add(pub);
            }
            for(int i=0;i<listaPublicacoes.size();i++)
            {
                if(listaPublicacoes.get(i).tipo.equals("AP")){
                    query="select revista from revista where id_publicacao="+listaPublicacoes.get(i).id_publicacao.toString();
                }
                else if(listaPublicacoes.get(i).tipo.equals("CL")){
                    query="select livro from capitulo where id_publicacao="+listaPublicacoes.get(i).id_publicacao.toString();
                }
                else if(listaPublicacoes.get(i).tipo.equals("TC")){
                    query="select evento from conferencia where id_publicacao="+listaPublicacoes.get(i).id_publicacao.toString();
                }
                else if(listaPublicacoes.get(i).tipo.equals("AA")){
                    query="select revista from revista_aceito where id_publicacao="+listaPublicacoes.get(i).id_publicacao.toString();
                }
                rs= st.executeQuery(query);
                rs.next();
                listaPublicacoes.get(i).localPublicado=rs.getString(1);
                
                query="select nome from membros where id_membro="+listaPublicacoes.get(i).id_membro;
                rs=st.executeQuery(query);
                rs.next();
                listaPublicacoes.get(i).nome_membro=rs.getString(1);
            }  
            
            query="select nome from membros where id_membro="+id_membro1;
            rs=st.executeQuery(query);
            rs.next();
            nome_membro1=rs.getString(1);
            
            query="select nome from membros where id_membro="+id_membro2;
            rs=st.executeQuery(query);
            rs.next();
            nome_membro2=rs.getString(1);
            
            rs.close();
            st.close();
            
            for(int i=0;i<listaPublicacoes.size()-1;i++)
            {
                if(listaPublicacoes.get(i).cluster==listaPublicacoes.get(i+1).cluster)
                {
                    listaImprime.add(listaPublicacoes.get(i));
                    listaPublicacoes.get(i).replica=listaPublicacoes.get(i+1);
                }   
            }   
            
        new guiListaPublicacoes();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
//        catch(java.lang.ArrayIndexOutOfBoundsException e)
//        {
//            System.out.println("Parâmetros inválidos");
//        }
    }
}
