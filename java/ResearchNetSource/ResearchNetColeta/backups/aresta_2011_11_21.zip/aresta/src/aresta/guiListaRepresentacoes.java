package aresta;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

public class guiListaRepresentacoes {
    public guiListaRepresentacoes(int clicked){
        //JFrame janela= new JFrame("Representações");
        
        publicacao pub1= aresta.listaImprime.get(clicked);
        publicacao pub2= aresta.listaImprime.get(clicked).replica;
        
        String repres = "<html><i>Currículo de origem: </i> "+pub1.nome_membro+"<br>"+pub1.toString().substring(6);
        
        repres=repres.substring(0, repres.length()-10);
        
        repres = repres + "<br><i>Currículo de origem: </i>"+pub2.nome_membro+"<br>"+pub2.toString().substring(6);
         
        repres = repres.substring(0, repres.length()-10);
        
        repres = repres + "<br><br><p align=\"center\"> As referências bibliográficas acima referenciam a mesma produção científica?</p>";
              
        String[] opcoes = new String[3];
        opcoes[0]="Sim";
        opcoes[1]="Não";
        opcoes[2]="Fechar";
        
        JOptionPane option = new JOptionPane();
        //option.setMessage("Validação");
        option.setMessage(repres);
        option.setOptions(opcoes);
        option.setMessageType(JOptionPane.QUESTION_MESSAGE);
        option.setIcon(null);
        
        JDialog dialogo = option.createDialog(null);
        dialogo.setVisible(true);
        
        //System.out.println(option.getValue());
        
        if(option.getValue()=="Sim"){
            
            
        }
        else if(option.getValue()=="Não")
        {
            
        }
               
    }
}
